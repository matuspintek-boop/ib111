from ib111 import week_01

password = "STANFORD"

if password == "STANFORD":
    message = "Imminent threat!"
else:
    message = "Access denied!"
