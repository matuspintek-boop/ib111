from ib111 import week_01


def number_of_hens(heads, legs):
    for hens in range(heads + 1):
        pigs = heads - hens
        if 2 * hens + 4 * pigs == legs:
            return hens

    # a special value to represent «no solution»
    return -1

# what is the value of number_of_hens(20, 56)?
# what is the value of number_of_hens(40, 100)?
