from ib111 import week_01

heads = 20
legs = 56
# -1: a special value to represent «no solution»
sol_hens = -1
sol_pigs = -1

for hens in range(heads + 1):
    pigs = heads - hens
    if 2 * hens + 4 * pigs == legs:
        sol_hens = hens
        sol_pigs = pigs
        break

# what is the value of sol_hens, sol_pigs?
