from ib111 import week_01
from turtle import forward, done
import math

forward(150 * math.sin(30.0 / 180.0 * math.pi))
done()
