from ib111 import week_01

answer = -6 * 7
if answer < 0:
    answer = -answer

# what is the value of answer here?
