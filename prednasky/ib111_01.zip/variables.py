answer = 6 * 7
name = "John"

# what is the value of answer?
# what is the value of name?
# what is the value of (answer == 42)?
