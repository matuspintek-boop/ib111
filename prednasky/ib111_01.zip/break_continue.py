from ib111 import week_01

total = 0
for i in range(10):
    if i == 3:
        continue
    if i == 7:
        break
    total += i

# what is the value of total now?
