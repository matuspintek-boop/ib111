from ib111 import week_01

answer = 6 * 7
universe_ok = answer == 42
answer_positive = answer > 0
answer_natural = answer_positive or answer == 0
