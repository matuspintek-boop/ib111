from ib111 import week_01

x = 10000
d = 0

while x > 0:
    x = x // 10
    d += 1

# what is the value of x, d here?
