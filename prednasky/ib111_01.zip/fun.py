from ib111 import week_01


def deg_to_rad(degrees):
    pi = 3.14
    return degrees / 180.0 * pi


angle = deg_to_rad(30)
