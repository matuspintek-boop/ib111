from ib111 import week_01

x = -17
if x > 0:
    status = "kladné"
elif x < 0:
    status = "záporné"
else:
    status = "nula (není ani kladná ani záporná)"
