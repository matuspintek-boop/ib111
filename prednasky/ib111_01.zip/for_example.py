from ib111 import week_01

total = 0

for i in range(10):
    total = total + i

# what is the value of total here?
