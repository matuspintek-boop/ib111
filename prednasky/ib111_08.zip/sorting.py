def sorted_by_len(lists: list[list[int]]) \
        -> list[list[int]]:
    len_lists = [(len(s), s) for s in lists]
    len_lists.sort()
    return [s for _, s in len_lists]


def sorted_by_len_stable(lists: list[list[int]]) \
        -> list[list[int]]:
    len_i_lists = [(len(s), i, s)
                   for i, s in enumerate(lists)]
    len_i_lists.sort()
    return [s for _, _, s in len_i_lists]


def sorted_by_len_stable_alt(lists: list[list[int]]) \
        -> list[list[int]]:
    len_i = [(len(s), i)
             for i, s in enumerate(lists)]
    len_i.sort()
    return [lists[i] for _, i in len_i]


class Person:
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age


def sorted_by_age(people: list[Person]) \
        -> list[Person]:
    ages_i = [(p.age, i)
              for i, p in enumerate(people)]
    ages_i.sort()
    return [people[i] for _, i in ages_i]


s: list[list[int]] = [[1, 2, 3], [], [1, 2], [9], [1, 3, 3, 7], [2]]
print(sorted(s))
print(sorted_by_len(s))
print(sorted_by_len_stable(s))
print(sorted_by_len_stable_alt(s))

some_people = [
    Person("John Constantine", 35),
    Person("Robert Gadling", 634),
    Person("Jed Walker", 12),
    Person("Joanna Constantine", 99),
    Person("Rose Walker", 21),
]

for p in sorted_by_age(some_people):
    print(p.name, p.age)
