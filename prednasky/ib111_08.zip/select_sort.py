def select_sort(my_list: list[int]) -> None:
    size = len(my_list)
    for i in range(size - 1):
        selected = i

        for j in range(i + 1, size):
            if my_list[j] < my_list[selected]:
                selected = j

        my_list[selected], my_list[i] = \
            my_list[i], my_list[selected]
