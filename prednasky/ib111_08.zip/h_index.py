def h_index(citations: list[int]) -> int:
    citations = sorted(citations)
    citations.reverse()

    h = 0
    while h < len(citations) and citations[h] > h:
        h += 1

    return h


cs = [37, 4, 9, 12, 39, 15, 3, 51, 11, 18, 39, 11, 36, 1, 16, 4, 6,
      10, 9, 3, 3, 28, 9, 5, 1, 7, 18, 63, 0, 20, 5, 21, 24, 40, 20,
      12, 17, 17, 3, 0, 3, 28, 5, 8, 3, 5, 15, 1, 4, 5, 26, 4, 1, 2,
      10, 2, 2, 0, 8, 4, 0]
