def unique_elements(my_list: list[int]) -> list[int]:
    result = []
    last: int | None = None
    # we don't want to change the input list
    for elem in sorted(my_list):
        if elem != last:
            result.append(elem)
            last = elem
    return result
