def insert_sort(my_list: list[int]) -> None:
    size = len(my_list)
    for i in range(1, size):
        # my_list[0], …, my_list[i - 1] is sorted
        # the rest is not sorted yet
        current = my_list[i]
        j = i
        while j > 0 and my_list[j - 1] > current:
            my_list[j] = my_list[j - 1]
            j -= 1
        my_list[j] = current
