def fun(s):
    s.append(3)
    s = [42, 17]
    s.append(9)
    return s


t = [1, 2]
u = fun(t)
print(t, u)

v = fun(t + u)
print(t, u, v)
