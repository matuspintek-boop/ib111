def increment(x):
    print(x, id(x))
    x += 1
    print(x, id(x))


def add_to_list(s):
    print(s, id(s))
    s += [1]
    print(s, id(s))


p = 2020
increment(p)
print(p, id(p))

t = [1, 2, 3]
add_to_list(t)
print(t, id(t))
