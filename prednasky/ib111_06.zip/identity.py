a = 1000
b = a
b += 1  # same as: b = b + 1
assert id(a) != id(b)

s = [1]
t = s  # try changing to: t = s.copy()
s.append(2)
assert id(s) == id(t)
