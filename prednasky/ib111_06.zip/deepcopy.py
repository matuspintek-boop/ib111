def list2d_copy(s: list[list[int]]) \
        -> list[list[int]]:
    return [row.copy() for row in s]


def dict_list_copy(d: dict[str, list[int]]) \
        -> dict[str, list[int]]:
    clone = {}
    for key, value in d.items():
        clone[key] = value.copy()
    return clone
