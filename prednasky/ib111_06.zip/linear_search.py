def contains(haystack: list[int], needle: int) -> bool:
    for element in haystack:
        if element == needle:
            return True
    return False


def index_of(haystack: list[int], needle: int) \
        -> int | None:
    for index, element in enumerate(haystack):
        if element == needle:
            return index
    return None
