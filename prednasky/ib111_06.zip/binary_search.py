def binary_search(haystack: list[int], needle: int) \
        -> bool:
    lower = 0
    upper = len(haystack)
    while lower < upper:
        middle = (lower + upper) // 2
        if haystack[middle] == needle:
            return True

        if haystack[middle] < needle:
            lower = middle + 1
        else:
            upper = middle

    return False


def find_boundary(nums: list[int], limit: int) -> int:
    lower = 0
    upper = len(nums)
    while lower < upper:
        middle = (lower + upper) // 2
        if nums[middle] < limit:
            lower = middle + 1
        else:
            upper = middle

    return lower


def binary_search_alt(haystack: list[int],
                      needle: int) -> bool:
    b = find_boundary(haystack, needle)
    return b < len(haystack) and haystack[b] == needle
