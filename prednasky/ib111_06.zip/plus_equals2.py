def add_to_list1(s):
    print(s, id(s))
    s += [1]
    print(s, id(s))


def add_to_list2(s):
    print(s, id(s))
    s = s + [1]
    print(s, id(s))


t = [1, 2, 3]
add_to_list1(t)
print(t)

t = [1, 2, 3]
add_to_list2(t)
print(t)
