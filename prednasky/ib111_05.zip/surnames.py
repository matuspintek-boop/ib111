def group_by_surname(names: list[tuple[str, str]]) \
        -> dict[str, list[str]]:
    groups: dict[str, list[str]] = {}
    for name, surname in names:
        if surname not in groups:
            groups[surname] = []

        groups[surname].append(name)

    return groups


some_names = [
    ('Liet', 'Kynes'),
    ('Paul', 'Atreides'),
    ('Feyd-Rautha', 'Harkonnen'),
    ('Jessica', 'Atreides'),
    ('Vladimir', 'Harkonnen')
]

# group_by_surname(some_names)
