def add_to_start(a_list: list[int],
                 value: int) -> None:
    for i, orig in enumerate(a_list):
        a_list[i] = value
        value = orig

    a_list.append(value)


def reverse1(my_list: list[int]) -> list[int]:
    result: list[int] = []
    for elem in my_list:
        add_to_start(result, elem)
    return result


def reverse2(my_list: list[int]) -> list[int]:
    result = []
    for i in range(len(my_list) - 1, -1, -1):
        result.append(my_list[i])
    return result
