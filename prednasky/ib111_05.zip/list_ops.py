def reverse_inplace(my_list: list[int]) -> None:
    for i in range(len(my_list) // 2):
        my_list[i], my_list[-i - 1] = \
            my_list[-i - 1], my_list[i]


def contains(haystack: list[int], needle: int) -> bool:
    for elem in haystack:
        if elem == needle:
            return True
    return False


def join(left: list[int], right: list[int]) -> list[int]:
    result = []
    for lst in [left, right]:
        for elem in lst:
            result.append(elem)
    return result


def extend(left: list[int], right: list[int]) -> None:
    for elem in right:
        left.append(elem)


def join_alt(left: list[int], right: list[int]) -> list[int]:
    result = left.copy()
    extend(result, right)
    return result
