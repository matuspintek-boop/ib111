def word_freq(words: list[str]) -> dict[str, int]:
    freq: dict[str, int] = {}
    for word in words:
        freq[word] = freq.get(word, 0) + 1
    return freq


laf = ["I", "must", "not", "fear",
       "fear", "is", "the", "mind", "killer",
       "fear", "is", "the", "little", "death",
       "that", "brings", "total", "obliteration",
       "I", "will", "face", "my", "fear",
       "I", "will", "permit", "it", "to", "pass",
       "over", "me", "and", "through", "me",
       "and", "when", "it", "has", "gone", "past",
       "I", "will", "turn", "the", "inner", "eye",
       "to", "see", "its", "path",
       "where", "the", "fear", "has", "gone",
       "there", "will", "be", "nothing",
       "only", "I", "will", "remain"]

# word_freq(laf)
