def contains(haystack: list[int], needle: int) -> bool:
    for elem in haystack:
        if elem == needle:
            return True
    return False


def unique_elements1(my_list: list[int]) -> list[int]:
    result: list[int] = []
    for element in my_list:
        if not contains(result, element):
            result.append(element)
    return result


def unique_elements2(my_list: list[int]) -> list[int]:
    return list(set(my_list))


def unique_elements3(my_list: list[int]) -> list[int]:
    seen = set()
    result = []
    for elem in my_list:
        if elem not in seen:
            result.append(elem)
            seen.add(elem)
    return result
