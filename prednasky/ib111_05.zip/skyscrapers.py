def clear_view(heights: list[int]) -> list[int]:
    stack: list[int] = []
    for current in range(len(heights)):
        while len(stack) > 0 and \
                heights[stack[-1]] < heights[current]:
            stack.pop()
        stack.append(current)

    return stack
