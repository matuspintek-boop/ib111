# Warning: this code is really bad. Don't write things like this.

def allow_import(imports: list[str],
                 allowed: list[str]) -> bool:
    for lib in imports:
        if lib not in set(allowed):
            return False
    return True


def lookup(phonebook: dict[str, int],
           person_name: str) -> int | None:
    for name, phone in phonebook.items():
        if name == person_name:
            return phone
    return None
