def weird(x):
    return ((1 + 1.0 / x) - 1) * x


# weird(2 ** 50) == 1.0
# weird(2 ** 100) == 0.0
# weird(3) == 0.9999999999999998
