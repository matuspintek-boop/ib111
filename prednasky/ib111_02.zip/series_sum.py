def series_sum(num):
    total = 0
    for i in range(1, num + 1):
        total += i
    return total


# what is the value of series_sum(42)?
