total = 0
i = 10
while i < 100:
    total += i
    i += 7
