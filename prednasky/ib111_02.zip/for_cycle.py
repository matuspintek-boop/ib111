total = 0
for i in range(10, 100, 7):
    total += i
