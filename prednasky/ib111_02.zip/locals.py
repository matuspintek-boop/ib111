# use pythontutor.com or a debugger

def inner(n):
    x = 2 * n
    return x + 11


def outer(n):
    x = 3 * n
    y = inner(n + 7)
    return x + y


x = 17
n = 33
result = outer(9)
