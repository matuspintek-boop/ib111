def square_root(x, precision):
    lower = 0.0
    upper = x
    middle = (lower + upper) / 2
    while abs(middle ** 2 - x) > precision:
        if middle ** 2 > x:
            upper = middle
        elif middle ** 2 < x:
            lower = middle
        middle = (lower + upper) / 2
    return middle
