from math import floor, ceil, trunc

height = float(10)

value = 3.14
rv = round(value)
fv = floor(value)
cv = ceil(value)
tv = trunc(value)
