# title, author, price
Book = tuple[str, str, float]


def get_book(database: list[Book], title: str) \
        -> Book | None:
    for book in database:
        book_title, _, _ = book
        if book_title == title:
            return book
    return None


my_books = [
    ("Dune", "Frank Herbert", 686.90),
    ("The Absolute Sandman", "Neil Gaiman", 1276.70),
    ("Doupě latinářů", "Ivan Wernish", 131.00),
]
