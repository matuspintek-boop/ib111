def maybe_get_pair() -> tuple[int, int] | None:
    return 0, 0


if maybe_get_pair() is not None:
    row, col = maybe_get_pair()
