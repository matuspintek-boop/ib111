def argmin(a_list):
    m = min(a_list)
    for i, value in enumerate(a_list):
        if m == value:
            return i

    assert False
