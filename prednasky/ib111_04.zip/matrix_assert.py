def matrix_mult(left, right):
    l_rows, l_cols = matrix_size(left)
    r_rows, r_cols = matrix_size(right)
    assert l_cols == r_rows, \
        "Incompatible matrix sizes"

    rows, cols = l_rows, r_cols
    common = l_cols

    result = null_matrix(rows, cols)
    for i in range(rows):
        for j in range(cols):
            for k in range(common):
                result[i][j] += left[i][k] * right[k][j]
    return result


def matrix_size(matrix):
    rows = len(matrix)
    assert rows > 0, "The matrix is empty"
    cols = len(matrix[0])
    for i in range(1, len(matrix)):
        assert len(matrix[i]) == cols, \
            "Not all rows have the same length"
    return rows, cols


def null_matrix(rows, cols):
    return [[0 for _ in range(cols)]
            for _ in range(rows)]
