def safe_divide(p: float, q: float) -> float | None:
    return None if q == 0 else p / q


# this is a mypy-error:
# print(safe_divide(3.14, 7.0) + 1)

# all of this is OK:
result = safe_divide(3.14, 7.0)
if result is not None:
    # mypy knows result is not None here
    print(result + 1)

if result is None:
    print("None")
else:
    # mypy knows result is not None here
    print(result + 1)

assert result is not None
# mypy knows result is not None here
print(result + 1)
