def day_of_week(day: int, month: int, year: int) -> int:
    """Returns the day of week (0 for Sunday) for
    the given date in the Gregorian calendar."""
    # this uses a variation on Gauss's method as described in
    # en.wikipedia.org/wiki/Determination_of_the_day_of_the_week

    # shift month so that March = 1 and decrease year for Jan, Feb
    if month < 3:
        year -= 1
        month += 10
    else:
        month -= 2

    century = year // 100
    year %= 100

    return (day + (26 * month - 2) // 10 +
            year + (year // 4) +
            (century // 4) - 2 * century) % 7
