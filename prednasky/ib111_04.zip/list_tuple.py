def average(numbers: list[float]) -> float:
    return sum(numbers) / len(numbers)


# we need the annotation here, mypy cannot guess the type
my_list: list[int] = []


def minmax(num1: int, num2: int) -> tuple[int, int]:
    return min(num1, num2), max(num1, num2)
