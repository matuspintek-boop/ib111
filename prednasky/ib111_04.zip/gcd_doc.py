def gcd(a: int, b: int) -> int:
    """Returns the greatest common divisor of a, b.

    Assumes that both a, b are nonnegative
    and at most one of them is zero."""
    while b != 0:
        aux = a % b
        a = b
        b = aux
    return a
