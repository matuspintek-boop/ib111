def is_triangle(a: int, b: int, c: int) -> bool:
    return a + b > c and a + c > b and b + c > a


def fact(num):
    result = 1
    for i in range(2, num + 1):
        result *= i
    return result


# try changing the return type annotation
def annotated_fact(num: int) -> int:
    # mypy automatically deduces the type of result
    result = 1
    for i in range(2, num + 1):
        result *= i
    return result


# these are not really needed
city: str = "Sparta"
soldier_count = 300  # type: int


def say_hello(language: str, name: str) -> None:
    # this is again not really needed
    hello: str
    if language == "en":
        hello = "Hello"
    elif language == "dk":
        hello = "Hei"
    else:
        hello = "Saluton"

    print(hello, ", ", name, "!", sep="")
