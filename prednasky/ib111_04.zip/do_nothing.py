def do_nothing() -> None:
    """This does nothing.

    This really does nothing,
    but does so very efficiently."""
