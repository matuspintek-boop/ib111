list_maybe: list[int | None] = [1, 3, None, 3, 7]

# this works with mypy
assert list_maybe[1] is not None
num = list_maybe[1] + 1

# this, sadly, doesn't (for principial reasons)
i = 3
assert list_maybe[i] is not None
num = list_maybe[i] + 1

total = 0
for i in range(len(list_maybe)):
    if list_maybe[i] is not None:
        total += list_maybe[i]

# solution
i = 3
ith_elem = list_maybe[i]
assert ith_elem is not None
num = ith_elem + 1

total = 0
for elem in list_maybe:
    if elem is not None:
        total += elem
