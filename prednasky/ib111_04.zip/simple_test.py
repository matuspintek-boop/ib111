def test_fact1():
    if fact(17) == 355687428096000:
        print("OK")
    else:
        print("Chyba! Funkce fact dává špatný "
              "výsledek pro vstup 17.")
    # ...


def test_fact2():
    assert fact(17) == 355687428096000, \
        "Špatný výsledek pro vstup 17."
    # ...


def fact(num):
    result = 0
    for i in range(num):
        result *= i
    return result
