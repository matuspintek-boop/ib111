def fun1() -> int:
    if answer() == 42:
        return answer()
    return 0


def fun2() -> int:
    result = answer()
    if result == 42:
        return result
    return 0


def answer() -> int:
    global_list.append(0)
    return len(global_list)


global_list: list[int] = []
