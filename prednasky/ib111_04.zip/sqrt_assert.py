def square_root(x, precision):
    lower = 0.0
    upper = x
    middle = (lower + upper) / 2
    while abs(middle ** 2 - x) > precision:
        assert lower ** 2 <= x <= upper ** 2, \
            "The solution is outside the bounds."
        if middle ** 2 > x:
            upper = middle
        elif middle ** 2 < x:
            lower = middle
        middle = (lower + upper) / 2
    return middle


# try running square_root(0.5, 0.01)
