s = []
s = [3, 1, 4, 1, 5]
s = ["ABC", 3.14, -7]
s = [[1, 2], [3, 4]]
s = ["pes", "kočka", 0.01, ["velbloud", -13], []]

s = [2 * x for x in range(10)]
s = [x ** 2 for x in range(1, 10) if x % 2 == 0]
s = [3 * x for x in [5, 17, 23, 40]]
s = [[a, b, c] for a in range(1, 10)
     for b in range(1, 10)
     for c in range(1, 10)
     if a ** 2 + b ** 2 == c ** 2]
