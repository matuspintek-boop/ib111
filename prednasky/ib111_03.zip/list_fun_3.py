def fun_3(s):
    s.append(17)
    s = [4, 5]
    s.append(19)


t = [1, 2]
fun(t)

# what is the value of t now?
