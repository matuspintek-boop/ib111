def fun_4(t):
    t.append(0)


def fun_5(a, b, c):
    s = [a, b, c]
    fun_4(s)


fun_5(1, 2, 3)

# Is fun_4 pure?
# Is fun_5 pure?

