def fun_1(x):
    x = 17


y = 10
fun_1(y)

# what is the value of y now?
