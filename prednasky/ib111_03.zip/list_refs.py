s = [1, 2, 3]
t = s
s.append(4)

# what is the value of t here?
# try changing the second line to t = s.copy(); what happens now?
