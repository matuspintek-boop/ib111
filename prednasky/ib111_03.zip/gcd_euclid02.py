def gcd(a, b):
    while b != 0:
        aux = a % b
        a = b
        b = aux
    return a
