def null_matrix_bad(rows, cols):
    row = [0 for _ in range(cols)]
    matrix = []
    for _ in range(rows):
        matrix.append(row)

    return matrix  # why is this bad?


def null_matrix_good(rows, cols):
    row = [0 for _ in range(cols)]
    matrix = []
    for _ in range(rows):
        matrix.append(row.copy())

    return matrix


def null_matrix(rows, cols):
    return [[0 for _ in range(cols)]
            for _ in range(rows)]


def coord_matrix(rows, cols):
    return [[(x, y) for x in range(cols)]
            for y in range(rows)]


def matrix_mult(left, right):
    rows = len(left)
    cols = len(right[0])
    common = len(right)
    result = null_matrix(rows, cols)
    for i in range(rows):
        for j in range(cols):
            for k in range(common):
                result[i][j] += left[i][k] * right[k][j]
    return result


def print_matrix(matrix):
    for row in matrix:
        print(row)


mat = [[1, 2, 3],
       [4, 5, 6],
       [7, 8, 9]]

print(mat[1][2])  # 6
print()
print_matrix(mat)
print()

cm = coord_matrix(3, 4)
print(cm[1][2])  # (2, 1)
print()
print_matrix(cm)
print()

a = [[1, 2, 3],
     [4, 5, 6]]

b = [[0, 1, 2, 3],
     [9, 0, 1, 4],
     [8, 7, 6, 5]]

print_matrix(matrix_mult(a, b))
