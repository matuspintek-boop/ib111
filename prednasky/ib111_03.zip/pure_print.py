def fun_6(n, do_print):
    if do_print:
        print(n)
    return n+1


def fun_7(n):
    return fun_6(n, False)


fun_7(0)

# Is fun_6 pure?
# Is fun_7 pure?

