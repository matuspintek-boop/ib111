def sieve(limit):
    result = []
    is_prime = [True for _ in range(limit)]

    for p in range(2, limit):
        if is_prime[p]:
            result.append(p)
            for mult in range(p * p, limit, p):
                is_prime[mult] = False

    return result
