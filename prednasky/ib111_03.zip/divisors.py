def divisors(num):
    result = []
    for divisor in range(1, num + 1):
        if num % divisor == 0:
            result.append(divisor)
    return result


def divisors_alt(num):
    return [divisor for divisor in range(1, num + 1)
            if num % divisor == 0]


def divisors_faster(num):
    result = []
    divisor = 1
    while divisor * divisor < num:
        if num % divisor == 0:
            result.append(divisor)
            result.append(num // divisor)
        divisor += 1
    if divisor * divisor == num:
        result.append(divisor)
    # what if I want the result ordered?
    return result
