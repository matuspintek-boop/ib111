s = (1, "A", 3)

data = ("Rick Sanchez", "C-137", "Earth")
name, dimension, planet = data

children = [
    (1, "Henry"),
    (8, "Kali"),
    (11, "Jane"),
]

for number, name in children:
    pass  # do something with number, name

a, b = 10, 17
# the same as a = 10 followed by b = 17

a, b = b, a  # the same as (a, b) = (b, a)


def minmax(a, b):
    return min(a, b), max(a, b)


x, y = minmax(9.7, 3.14)

quot, rem = divmod(17, 5)  # standard Python function
