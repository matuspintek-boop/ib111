def fun_2(s):
    s.append(17)


t = [1, 2]
fun_2(t)

# what is the value of t now?
