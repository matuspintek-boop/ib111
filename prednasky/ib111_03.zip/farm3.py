def solve_hens_pigs_puzzle(heads, legs):
    for hens in range(heads + 1):
        pigs = heads - hens
        if 2 * hens + 4 * pigs == legs:
            return (hens, pigs)

    return None


# what is the value of solve_hens_pigs_puzzle(20, 56)?
# what is the value of solve_hens_pigs_puzzle(40, 100)?
