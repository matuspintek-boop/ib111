def my_sum(data):
    total = 0
    for element in data:
        total += element
    return total


def my_max(data):
    best = data[0]
    for element in data:
        if element > best:
            best = element
    return best
