class Matrix:
    def __init__(self, rows: int, cols: int):
        self.rows = rows
        self.cols = cols
        self.matrix = [[0 for j in range(self.cols)]
                       for i in range(self.rows)]

    def check(self, row: int, col: int) -> None:
        assert 0 <= row < self.rows
        assert 0 <= col < self.cols

    def get(self, row: int, col: int) -> int:
        self.check(row, col)
        return self.matrix[row][col]

    def set(self, row: int, col: int,
            value: int) -> None:
        self.check(row, col)
        self.matrix[row][col] = value

    def output(self) -> None:
        for row in self.matrix:
            print(row)


def matrix_mult(left: Matrix, right: Matrix) -> Matrix:
    assert left.cols == right.rows, \
        "Incompatible matrices."

    result = Matrix(left.rows, right.cols)
    for i in range(left.rows):
        for j in range(right.cols):
            for k in range(left.cols):
                result.set(i, j, result.get(i, j) +
                           left.get(i, k) *
                           right.get(k, j))

    return result


# let's try multiplying these matrices:
# 0 1     1 1
# 1 1  *  1 0

a = Matrix(2, 2)
b = Matrix(2, 2)

a.set(0, 1, 1)
a.set(1, 0, 1)
a.set(1, 1, 1)
a.output()

b.set(0, 1, 1)
b.set(1, 0, 1)
b.set(0, 0, 1)
b.output()

c = matrix_mult(a, b)
c.output()
