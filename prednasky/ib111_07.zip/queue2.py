class Node:
    def __init__(self, data: str):
        self.data = data
        self.next: Node | None = None


class Queue:
    def __init__(self) -> None:
        self.first: Node | None = None
        self.last: Node | None = None

    def push(self, data: str) -> None:
        node = Node(data)
        if self.last is None:
            self.first = node
        else:
            self.last.next = node
        self.last = node

    def pull(self) -> str:
        assert self.first is not None
        result = self.first.data
        self.first = self.first.next
        if self.first is None:
            self.last = None
        return result
