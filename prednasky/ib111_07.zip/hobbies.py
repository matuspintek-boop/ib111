class Student:
    # static attribute, belongs to the class, not to its objects
    hobbies: list[str] = []

    def __init__(self, name: str):
        self.name = name

    def add_hobby(self, hobby: str) -> None:
        self.hobbies.append(hobby)


mirek = Student("Mirek Dušín")
mirek.add_hobby("pomáhání slabším")
mirek.add_hobby("světový mír")

bidlo = Student("Dlouhé Bidlo")
bidlo.add_hobby("alkohol")

print(mirek.hobbies)

# how do we fix this?
