class Dog:
    def make_sound(self) -> None:
        print("Whoof!")


class Cat:
    def make_sound(self) -> None:
        print("Meow!")


class SmallFurryAnimalFromAlphaCentauri:
    def make_sound(self) -> None:
        print("Qwxrq!")


fido = Dog()
fido.make_sound()

felix = Cat()
felix.make_sound()

frrq = SmallFurryAnimalFromAlphaCentauri()
frrq.make_sound()
