class Student:
    def __init__(self, uco: int, name: str):
        self.uco = uco
        self.name = name


class Course:
    def __init__(self, code: str):
        self.code = code
        self.students: list[Student] = []

    def add_student(self, student: Student) -> None:
        self.students.append(student)

    def get_student_names(self) -> list[str]:
        names = []
        for student in self.students:
            names.append(student.name)
        return names


jimmy = Student(555007, "James Bond")

ib111 = Course("IB111")

ib111.add_student(Student(555000, "Jan Novák"))
ib111.add_student(jimmy)
ib111.add_student(Student(999999, "Kryštof Harant"))
