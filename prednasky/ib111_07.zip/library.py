class Book:
    def __init__(self,
                 author: str, title: str, isbn: str):
        self.author = author
        self.title = title
        self.isbn = isbn


# this is how we create books:
dune = Book("Frank Herbert", "Dune", "978-0441172719")
temno = Book("Bohuslav Balcar & Petr Štěpánek",
             "Teorie množin", "80-200-0470-X")
