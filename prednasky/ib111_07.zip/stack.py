class Node:
    def __init__(self, data: str):
        self.data = data
        self.next: Node | None = None


class Stack:
    def __init__(self) -> None:
        self.top: Node | None = None

    def empty(self) -> bool:
        return self.top is None

    def push(self, data: str) -> None:
        node = Node(data)
        node.next = self.top
        self.top = node

    def pop(self) -> str:
        assert self.top is not None
        result = self.top.data
        self.top = self.top.next
        return result
