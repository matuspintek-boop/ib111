class Person:
    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

    def say_hello(self) -> None:
        print(self.name, "says hello.")

    def grow_old(self, how_much: int) -> None:
        self.age += how_much

    def is_adult(self) -> bool:
        return self.age >= 18


homer = Person("Homer Simpson", 34)
homer.say_hello()

homer.grow_old(6)
print(homer.is_adult())
