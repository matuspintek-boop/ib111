class Node:
    def __init__(self, data: str):
        self.data = data
        self.next: Node | None = None


class LinkedList:
    def __init__(self) -> None:
        self.first: Node | None = None

    def add_to_beginning(self, data: str) -> None:
        node = Node(data)
        node.next = self.first
        self.first = node

    def delete_first(self) -> None:
        if self.first is not None:
            self.first = self.first.next

    def to_list(self) -> list[str]:
        result = []
        node = self.first
        while node is not None:
            result.append(node.data)
            node = node.next
        return result


my_ll = LinkedList()
my_ll.add_to_beginning("Hello")
my_ll.add_to_beginning("Ahoj")
elems1 = my_ll.to_list()
my_ll.delete_first()
elems2 = my_ll.to_list()
